To run the runnable jar file=>

First go to the directory where part2.jar is located
Then use this command line:
java -jar part2.jar
