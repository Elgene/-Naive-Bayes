package question2;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;


public class NaiveBayes {

    private final int features = 12;
    ArrayList<ArrayList<Integer>> dataTraining, dataTesting;
    private boolean isTestData;

    private int totalSpamValue;
    private int totalNotSpamValue;

    private final int[] trueSpam = new int[features];
    private final int[] falseSpam = new int[features];

    private final int[] trueNotSpam = new int[features];
    private final int[] falseNotSpam = new int[features];

    static String indentLine = "=======================================================================================================================";

    public NaiveBayes() {
        isTestData = false;
        totalSpamValue = 0;
        totalNotSpamValue = 0;
        dataTesting = readFiles("question2/spamUnlabelled.dat", features - 1);
        dataTraining = readFiles("question2/spamLabelled.dat", features);

    }

    /**
     * Calculation the probability of spam and not spam from the email
     * @param instances instances from data
     */
    private void naiveBayesClassifier(ArrayList<ArrayList<Integer>> instances) {
        System.out.println(indentLine);
        int countValue = 1;
        int matchValue = 0;

        if (!isTestData) {
            for (ArrayList<Integer> ins : instances) {
                boolean isSpamming = calcProbability(ins, countValue++);
                if ((isSpamming && ins.get(12) == 1) || (!isSpamming && ins.get(12) == 0)) matchValue++; //getting the accuracy of test data set
            }
            double accuracy = (double) matchValue * 100 / instances.size();

            System.out.println(indentLine +"\nTotal of Spam emails = "+ totalSpamValue);
            System.out.println("Total of Not spam emails = " + totalNotSpamValue);
            System.out.printf("Total of predicted values is %d/%d",matchValue, instances.size());
            System.out.printf("\nTherefore, the accuracy is %.2f%%",accuracy);

            System.out.println("\n\n" + indentLine + "\n" + "=> (Part 2 Question 1) The conditional probabilities P(Fi|C) for each feature i and each class label.\n" + indentLine);

            for (int i = 0; i < features; i++) {
                System.out.println("Feature " + (i+1) +":  P(F=1|C=1) = " + trueSpam[i] +"/" + totalSpamValue +" = "+ convertToThreeDecimal((double) trueSpam[i]/ totalSpamValue) + "   \t" +
                        "P(F=1|C=0) = " + falseNotSpam[i] +"/" + totalNotSpamValue +" = "+ convertToThreeDecimal((double) falseNotSpam[i]/ totalNotSpamValue)+ "   \t"+
                        "P(F=0|C=1) = " + falseSpam[i] +"/" + totalSpamValue +" = "+ convertToThreeDecimal((double) falseSpam[i]/ totalSpamValue) + "   \t"+
                        "P(F=0|C=0) = " + trueNotSpam[i] +"/" + totalNotSpamValue +" = "+ convertToThreeDecimal((double) trueNotSpam[i]/ totalNotSpamValue));
            }

        } else
            for (ArrayList<Integer> inst : instances) {
                calcProbability(inst, countValue++);
            }
    }


    /**
     * Perform the calculation of each probability of email given the relevant condition
     * @param instance from the data
     * @param countValue quantity of instance classifier
     * @return - true if the email is spam false otherwise
     */
    public boolean calcProbability(ArrayList<Integer> instance, int countValue) {
        double probSpam = (double) totalSpamValue / (double) (totalSpamValue + totalNotSpamValue);
        double probNotSpam = (double) totalNotSpamValue / (double) (totalSpamValue + totalNotSpamValue);

        for (int i = 0; i < features; i++) {
            if (instance.get(i) == 1) { // for true values of attributes
                probSpam *= (double) trueSpam[i] / (double) (trueSpam[i] + falseSpam[i]);
                probNotSpam *= (double) trueNotSpam[i] / (double) (trueNotSpam[i] + falseNotSpam[i]);
            } else { //for false value of attributes
                probSpam *= (double) falseSpam[i] / (double) (trueSpam[i] + falseSpam[i]);
                probNotSpam *= (double) falseNotSpam[i] / (double) (trueNotSpam[i] + falseNotSpam[i]);
            }
        }

        // using normalisation rule
        double denominator = probNotSpam + probSpam;
        probSpam /= denominator;
        probNotSpam /= denominator;

        // Assuming prediction
        String predictedIns = (probSpam > probNotSpam) ? "SPAM" : "NOT SPAM";
        if (!isTestData) {
            String actualIns = ((instance.get(12) == 1) ? "SPAM" : "NOT SPAM");
            String matchIns = predictedIns.equals(actualIns) ? "Match" : "Mismatch";
            System.out.printf("Instance %d: P(Spam) = %2.2f%%     \t  P(Not Spam) = %2.2f%%     \tPredicted(%s) vs Actual(%s) -> %s\n", countValue, probSpam * 100, probNotSpam * 100, predictedIns, actualIns, matchIns);
        } else
            System.out.printf("Instance %d: P(Spam) = %2.2f%%  \t  P(Not spam) = %2.2f%%     \tPredicted value = %s \n", countValue, probSpam * 100, probNotSpam * 100, predictedIns);

        return (probSpam > probNotSpam);
    }

    /**
     * a method used to train Naive Bayes algorithm
     *
     * @param instances - the given instances
     */
    private void naiveBayesTraining(ArrayList<ArrayList<Integer>> instances) {
        for (ArrayList<Integer> instance : instances) { //calculate number of spam and not spam
            if (instance.get(instance.size() - 1) == 1) {
                totalSpamValue++;
            } else {
                totalNotSpamValue++;
            }

            // calculate toal of true and false features of spam and not spam
            for (int i = 0; i < features; i++) {
                if (instance.get(instance.size() - 1) == 1) {
                    if (instance.get(i) == 1){
                        trueSpam[i]++;
                    } else{
                        falseSpam[i]++;
                    }
                } else {
                    if (instance.get(i) == 1) {
                        trueNotSpam[i]++;
                    } else {
                        falseNotSpam[i]++;
                    }
                }
            }
        }
    }
    /**
     * Setter of testing data to true
     */
    private void setIsTestData() {
        this.isTestData = true;
    }

    /**
     * Convert to three decimal number
     * @param number double value
     * @return three decimal number
     */

    private double convertToThreeDecimal(double number) {
        DecimalFormat decimalValue = new DecimalFormat("##.###");
        return Double.parseDouble(decimalValue.format(number));
    }

    public static void main(String[] args) {
        NaiveBayes bayes = new NaiveBayes();
        bayes.naiveBayesTraining(bayes.dataTraining);

        System.out.println(indentLine +"\n => Classification of training data set:");
        bayes.naiveBayesClassifier(bayes.dataTraining);

        bayes.setIsTestData();

        System.out.println(indentLine +"\n => Classification of testing data set:");
        bayes.naiveBayesClassifier(bayes.dataTesting);
    }

    /**
     * Read files from training data set and testing data set
     * @param fileName file name
     * @param features features
     * @return instances
     */
    private ArrayList<ArrayList<Integer>> readFiles(String fileName, int features) {
        ArrayList<ArrayList<Integer>> instancesFile = new ArrayList<>();
        ArrayList<Integer> instanceFeatures;
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(fileName);
        assert is != null;
        Scanner scan = new Scanner(is);
        while (scan.hasNext()) {
            instanceFeatures = new ArrayList<>();
            for (int i = 0; i <= features; i++){
                instanceFeatures.add(scan.nextInt());
            }
            instancesFile.add(instanceFeatures);
        }
        scan.close();
        System.out.println("\n=>Loading " + instancesFile.size() + " instances from "+ fileName);
        return instancesFile;

    }


}
